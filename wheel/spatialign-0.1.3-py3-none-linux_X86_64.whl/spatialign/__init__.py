from .spatialign.trainer import Spatialign

__version__ = "0.1.2"
